<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

?>
<body id="<?php echo $bodyId; ?>" class="<?php echo $bodyClasses; ?> backend-import" >
